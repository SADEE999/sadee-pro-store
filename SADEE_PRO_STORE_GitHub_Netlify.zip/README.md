# SADEE PRO STORE

A mobile-friendly black/red storefront with a separate authenticated admin dashboard. Built for GitHub + Netlify + Supabase.

## Features
- Responsive store landing page, product search and category filters.
- Live product catalogue from Supabase.
- Customer order requests stored in Supabase.
- Separate `/admin/` sign-in, product create/edit/delete and order status management.
- Row Level Security policies so only UUIDs explicitly inserted into `admin_users` can manage inventory or read/update orders.
- No payment credentials or service-role keys in frontend code.

## 1. Create the Supabase backend
1. Create a project at https://supabase.com/ and open **SQL Editor**.
2. Open `supabase/schema.sql` from this repository, copy all of it, paste into SQL Editor and run.
3. In Supabase **Project Settings → API** (or API Keys), copy the Project URL and the publishable/anon public key.
4. Edit `config.js` in GitHub and replace:
   - `https://YOUR_PROJECT_ID.supabase.co`
   - `YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY`
   - Replace `hello@example.com` with the real store support email.
5. The public anon/publishable key is intended for browser use when Row Level Security is configured. **Never** put a `service_role` or secret key in `config.js`.

## 2. Create the admin login securely
1. In Supabase → **Authentication → Users**, create/invite your admin account. Do not add a public sign-up form.
2. Open the new user and copy its UUID.
3. In SQL Editor run this with your real UUID:
   ```sql
   insert into public.admin_users(user_id)
   values ('PASTE-ADMIN-USER-UUID-HERE');
   ```
4. Only this allowlisted user can manage products or read orders. If an account is not listed in `admin_users`, the admin page signs it out.
5. Test at `https://YOUR-SITE.netlify.app/admin/`. Use a unique password and keep it private.

## 3. Publish using GitHub from an Android phone
1. Create a new GitHub repository, e.g. `sadee-pro-store`.
2. Upload the project files/folders from this ZIP, preserving the structure:
   - `index.html`, `styles.css`, `config.js`, `store.js`, `README.md`
   - `admin/index.html`, `admin/admin.css`, `admin/admin.js`
   - `supabase/schema.sql`
3. Open https://netlify.com/ and sign in.
4. Choose **Add new site → Import an existing project**, connect GitHub, and select the repository.
5. For this plain HTML project, leave build command empty and publish directory as the repository root (`.` if required). Deploy.
6. After deploy, visit the site URL and `/admin/`.

## 4. Add and manage products
- Sign in at `/admin/` and use **Add product**.
- Image URL is optional. Use a stable public HTTPS image URL that you have permission to use. The image URL must be publicly accessible.
- Use product descriptions and prices that accurately represent the item.
- Delete the sample “Starter Gaming Pack” and add your real products before advertising the store.

## 5. Important production notes
- Customer orders are requests, not confirmed purchases. Contact the customer to confirm stock, delivery and payment terms before collecting payment.
- The sample schema accepts public order inserts, but a public website can still receive spam. Add rate limiting/CAPTCHA or a server-side function before a high-volume launch.
- The public order form submits product name and price from the browser. For a production store, use a Supabase Edge Function or other server-side validation to fetch current product price/stock and create the order. Do not treat browser-submitted totals as authoritative.
- Consider restricting who can update/delete products and adding image uploads with a private admin-only storage policy if you need them.
- Set a custom domain later in Netlify if desired.
- This project does not process card payments. Do not ask customers for passwords, OTPs or payment PINs.
