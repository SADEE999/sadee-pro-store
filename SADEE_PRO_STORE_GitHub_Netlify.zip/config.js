// Public browser configuration only. Never put a Supabase service_role key here.
window.STORE_CONFIG = {
  SUPABASE_URL: "https://YOUR_PROJECT_ID.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY",
  STORE_NAME: "SADEE PRO STORE",
  SUPPORT_EMAIL: "hello@example.com",
  CURRENCY: "LKR"
};