SADEE PRO STORE - GitHub ZIP extraction workflow

1. Copy .github/workflows/extract-zip.yml into the same path in your repository.
2. Commit that workflow file.
3. Upload your website ZIP to the repository root and commit it.
4. Open the Actions tab and check the Extract Website ZIP workflow.
5. The ZIP must contain index.html at its website root (possibly inside one wrapper folder).

Note: This workflow extracts static website files to the repository root. GitHub Pages cannot run Netlify Functions or other server-side functions. eZ Cash approval and license delivery need a separately hosted backend.
